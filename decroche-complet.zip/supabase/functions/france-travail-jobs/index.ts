import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface SearchParams {
  keywords?: string;
  commune?: string;
  codePostal?: string;
  distance?: number; // 10, 30, 50, 100 km
  contractType?: string; // CDI, CDD, MIS, etc.
  excludeInterim?: boolean;
  excludeTraining?: boolean;
  range?: string; // pagination e.g. "0-49"
}

interface FTOffer {
  id: string;
  intitule: string;
  description: string;
  dateCreation: string;
  dateActualisation?: string;
  lieuTravail?: {
    libelle?: string;
    commune?: string;
    codePostal?: string;
    latitude?: string;
    longitude?: string;
  };
  entreprise?: {
    nom?: string;
    logo?: string;
    description?: string;
    url?: string;
    entrepriseAdaptee?: boolean;
  };
  typeContrat?: string;
  typeContratLibelle?: string;
  natureContrat?: string;
  experienceExige?: string;
  experienceExigeLibelle?: string;
  salaire?: {
    libelle?: string;
    commentaire?: string;
  };
  contact?: {
    telephone?: string;
    email?: string;
    nom?: string;
    prenom?: string;
  };
  origineOffre?: {
    codeOrigine?: string;
    libelle?: string;
    urlOrigine?: string;
  };
  urlCandidature?: string;
  urlPostulation?: string;
  contactCandidature?: string;
  numeroOffre?: string;
  commune?: { code?: string; libelle?: string };
  appellationLibelle?: string;
  competence?: Array<{ code?: string; libelle?: string; niveauLibelle?: string }>;
  langue?: Array<{ code?: string; libelle?: string; niveau?: string; niveauLibelle?: string }>;
  formation?: Array<{ code?: string; domaineLibelle?: string; niveauLibelle?: string; niveau?: string }>;
  permis?: Array<{ code?: string; libelle?: string }>;
  qualitesProfessionnelles?: Array<{ code?: string; libelle?: string }>;
  rythmeParution?: string;
  alternance?: boolean;
  dureeTravailLibelle?: string;
  dureeTravail?: string;
  accesHandicap?: boolean;
  sensibilisationHandicap?: boolean;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const path = url.pathname.replace("/functions/v1/france-travail-jobs", "").replace("/france-travail-jobs", "");

    // GET /offer/:id — fetch single offer details
    const offerMatch = path.match(/^\/offer\/(.+)$/);

    if (req.method === "GET" && offerMatch) {
      const offerId = offerMatch[1];
      const offer = await fetchOfferDetail(offerId);
      return new Response(JSON.stringify(offer), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // POST /search — search job offers
    if (req.method === "POST" || req.method === "GET") {
      let params: SearchParams;
      if (req.method === "POST") {
        params = await req.json();
      } else {
        params = {
          keywords: url.searchParams.get("keywords") || undefined,
          commune: url.searchParams.get("commune") || undefined,
          codePostal: url.searchParams.get("codePostal") || undefined,
          distance: url.searchParams.get("distance") ? parseInt(url.searchParams.get("distance")!) : undefined,
          contractType: url.searchParams.get("contractType") || undefined,
          excludeInterim: url.searchParams.get("excludeInterim") !== "false",
          excludeTraining: url.searchParams.get("excludeTraining") !== "false",
          range: url.searchParams.get("range") || "0-49",
        };
      }

      const results = await searchOffers(params);
      return new Response(JSON.stringify(results), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Internal error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

// ======================== FRANCE TRAVAIL OAUTH2 ========================

let cachedToken: { token: string; expiresAt: number } | null = null;

async function getAccessToken(): Promise<string> {
  if (cachedToken && Date.now() < cachedToken.expiresAt - 60000) {
    return cachedToken.token;
  }

  const clientId = Deno.env.get("FRANCE_TRAVAIL_CLIENT_ID");
  const clientSecret = Deno.env.get("FRANCE_TRAVAIL_SECRET");

  if (!clientId || !clientSecret) {
    throw new Error("France Travail credentials not configured");
  }

  const tokenUrl = "https://entreprise.francetravail.fr/connexion/oauth2/access_token?realm=%2Fpartenaire";
  const scope = "api_offresdemploiv2 o2dsoffre";

  // Try client_secret_post (credentials in body) first — this is the documented method
  const bodyParams = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: clientId,
    client_secret: clientSecret,
    scope,
  });

  let resp = await fetch(tokenUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Accept": "application/json",
    },
    body: bodyParams.toString(),
  });

  // If body method fails, try client_secret_basic (HTTP Basic Auth header)
  if (!resp.ok && resp.status === 400) {
    const credentials = btoa(`${clientId}:${clientSecret}`);
    const basicBody = new URLSearchParams({
      grant_type: "client_credentials",
      scope,
    });

    resp = await fetch(tokenUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json",
        "Authorization": `Basic ${credentials}`,
      },
      body: basicBody.toString(),
    });
  }

  if (!resp.ok) {
    const text = await resp.text();
    if (text.includes("invalid_client")) {
      throw new Error("Authentification France Travail refusee. Verifie que ton application est abonnee a l'API Offres d'emploi v2 sur francetravail.io.");
    }
    throw new Error(`Failed to get France Travail token: ${resp.status} ${text}`);
  }

  const data = await resp.json();
  cachedToken = {
    token: data.access_token,
    expiresAt: Date.now() + data.expires_in * 1000,
  };
  return cachedToken.token;
}

// ======================== SEARCH OFFERS ========================

async function searchOffers(params: SearchParams) {
  const token = await getAccessToken();
  const apiUrl = "https://api.francetravail.fr/partenaire/offresdemploi/v2/offres/search";

  const queryParams = new URLSearchParams();

  if (params.keywords) queryParams.append("motsCles", params.keywords);
  if (params.commune) queryParams.append("commune", params.commune);
  if (params.codePostal) queryParams.append("commune", params.codePostal);
  if (params.distance) queryParams.append("distance", String(params.distance));
  if (params.contractType) queryParams.append("typeContrat", params.contractType);

  queryParams.append("range", params.range || "0-49");

  // Exclude interim agencies and training organizations
  // MIS = mission intérimaire (interim), we filter by typeContrat
  // We also filter out offers from training providers by checking the company name
  const excludeInterim = params.excludeInterim !== false;
  const excludeTraining = params.excludeTraining !== false;

  // If we want to exclude interim, don't request MIS type
  // We can't directly exclude via API, so we filter post-fetch

  const resp = await fetch(`${apiUrl}?${queryParams.toString()}`, {
    headers: {
      "Authorization": `Bearer ${token}`,
      "Accept": "application/json",
    },
  });

  if (!resp.ok) {
    const text = await resp.text();
    if (resp.status === 401) {
      cachedToken = null;
      throw new Error("Authentication expired. Please retry.");
    }
    if (resp.status === 429) {
      throw new Error("Trop de recherches. Réessaie dans quelques secondes.");
    }
    throw new Error(`France Travail API error: ${resp.status} ${text}`);
  }

  const data = await resp.json();

  let offers: FTOffer[] = data.resultats || [];

  // Filter out interim offers (typeContrat = MIS)
  if (excludeInterim) {
    offers = offers.filter(
      (o) => o.typeContrat !== "MIS" && o.typeContrat !== "SAI"
    );
  }

  // Filter out training/formation providers by company name keywords
  if (excludeTraining) {
    const trainingKeywords = [
      "formation",
      "organisme de formation",
      "centre de formation",
      "institut de formation",
      "formation professionnelle",
      "école",
      "afpa",
      "greata",
    ];
    offers = offers.filter((o) => {
      const company = (o.entreprise?.nom || "").toLowerCase();
      return !trainingKeywords.some((kw) => company.includes(kw));
    });
  }

  // Transform offers into our format
  const transformedOffers = offers.map((o) => ({
    external_id: o.id,
    title: o.intitule || "Poste à pourvoir",
    company: o.entreprise?.nom || "Entreprise non précisée",
    company_logo_url: o.entreprise?.logo || null,
    location: o.lieuTravail?.libelle || o.commune?.libelle || null,
    contract_type: o.typeContratLibelle || o.typeContrat || null,
    description: cleanDescription(o.description || ""),
    salary: o.salaire?.libelle || null,
    application_url: o.urlPostulation || o.urlCandidature || o.entreprise?.url || null,
    contact_phone: o.contact?.telephone || null,
    contact_email: o.contact?.email || null,
    contact_name: [o.contact?.prenom, o.contact?.nom].filter(Boolean).join(" ") || null,
    experience: o.experienceExigeLibelle || null,
    duree_travail: o.dureeTravailLibelle || null,
    alternance: o.alternance || false,
    accesHandicap: o.accesHandicap || false,
    numero_offre: o.numeroOffre || null,
    competences: o.competence?.map((c) => c.libelle).filter(Boolean) || [],
    formations: o.formation?.map((f) => f.niveauLibelle).filter(Boolean) || [],
    permis: o.permis?.map((p) => p.libelle).filter(Boolean) || [],
    date_creation: o.dateCreation || null,
    keywords: params.keywords ? [params.keywords] : [],
    city: params.commune || params.codePostal || null,
  }));

  // Cache results in database
  await cacheOffers(transformedOffers);

  return {
    total: data.totalResultats || transformedOffers.length,
    offers: transformedOffers,
    cached: false,
  };
}

// ======================== OFFER DETAIL ========================

async function fetchOfferDetail(offerId: string) {
  const token = await getAccessToken();
  const apiUrl = `https://api.francetravail.fr/partenaire/offresdemploi/v2/offres/${offerId}`;

  const resp = await fetch(apiUrl, {
    headers: {
      "Authorization": `Bearer ${token}`,
      "Accept": "application/json",
    },
  });

  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`Failed to fetch offer: ${resp.status} ${text}`);
  }

  const o: FTOffer = await resp.json();

  return {
    external_id: o.id,
    title: o.intitule || "Poste à pourvoir",
    company: o.entreprise?.nom || "Entreprise non précisée",
    company_logo_url: o.entreprise?.logo || null,
    company_description: o.entreprise?.description || null,
    location: o.lieuTravail?.libelle || null,
    code_postal: o.lieuTravail?.codePostal || null,
    contract_type: o.typeContratLibelle || o.typeContrat || null,
    description: cleanDescription(o.description || ""),
    salary: o.salaire?.libelle || null,
    salary_comment: o.salaire?.commentaire || null,
    application_url: o.urlPostulation || o.urlCandidature || null,
    contact_phone: o.contact?.telephone || null,
    contact_email: o.contact?.email || null,
    contact_name: [o.contact?.prenom, o.contact?.nom].filter(Boolean).join(" ") || null,
    experience: o.experienceExigeLibelle || null,
    duree_travail: o.dureeTravailLibelle || null,
    alternance: o.alternance || false,
    accesHandicap: o.accesHandicap || false,
    numero_offre: o.numeroOffre || null,
    competences: o.competence?.map((c) => ({ libelle: c.libelle, niveau: c.niveauLibelle })).filter((c) => c.libelle) || [],
    formations: o.formation?.map((f) => ({ domaine: f.domaineLibelle, niveau: f.niveauLibelle })).filter((f) => f.domaine) || [],
    permis: o.permis?.map((p) => p.libelle).filter(Boolean) || [],
    qualites: o.qualitesProfessionnelles?.map((q) => q.libelle).filter(Boolean) || [],
    langues: o.langue?.map((l) => ({ libelle: l.libelle, niveau: l.niveauLibelle })).filter((l) => l.libelle) || [],
    date_creation: o.dateCreation || null,
    entreprise_url: o.entreprise?.url || null,
    entreprise_adaptee: o.entreprise?.entrepriseAdaptee || false,
  };
}

// ======================== CACHE OFFERS ========================

async function cacheOffers(offers: Array<Record<string, unknown>>) {
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

  if (!supabaseUrl || !serviceKey) return;

  const supabase = createClient(supabaseUrl, serviceKey);

  for (const offer of offers) {
    await supabase
      .from("job_offers")
      .upsert(
        {
          external_id: offer.external_id,
          title: offer.title,
          company: offer.company,
          company_logo_url: offer.company_logo_url,
          location: offer.location,
          contract_type: offer.contract_type,
          description: offer.description,
          salary: offer.salary,
          application_url: offer.application_url,
          keywords: offer.keywords,
          city: offer.city,
          fetched_at: new Date().toISOString(),
          expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        },
        { onConflict: "external_id" }
      );
  }
}

// ======================== HELPERS ========================

function cleanDescription(desc: string): string {
  return desc
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/?[^>]+(>|$)/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\r\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}
