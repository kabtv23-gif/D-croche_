const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface CVFormData {
  fullName: string;
  email?: string;
  phone?: string;
  address?: string;
  targetRole?: string;
  experiences: Array<{
    company: string;
    position: string;
    startDate: string;
    endDate?: string;
    description?: string;
  }>;
  educations: Array<{
    diploma: string;
    school: string;
    year?: string;
    details?: string;
  }>;
  skills: string[];
  languages?: Array<{ name: string; level: string }>;
  summary?: string;
}

interface OptimizeRequest {
  action: "analyze_cv" | "create_cv" | "adapt_cv";
  cvText?: string;
  formData?: CVFormData;
  jobOffer?: {
    title: string;
    company: string;
    description: string;
    contract_type?: string;
    location?: string;
    competences?: string[];
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body: OptimizeRequest = await req.json();

    const apiKey = Deno.env.get("GEMINI_API_KEY");
    if (!apiKey) {
      throw new Error("Gemini API key not configured");
    }

    let result: string;

    switch (body.action) {
      case "analyze_cv":
        result = await analyzeCV(body, apiKey);
        break;
      case "create_cv":
        result = await createCV(body, apiKey);
        break;
      case "adapt_cv":
        result = await adaptCV(body, apiKey);
        break;
      default:
        throw new Error("Action non reconnue. Utilise analyze_cv, create_cv ou adapt_cv.");
    }

    return new Response(JSON.stringify({ result }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Erreur interne" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

async function callGemini(prompt: string, apiKey: string): Promise<string> {
  const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${apiKey}`;

  const resp = await fetch(apiUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 4096,
      },
    }),
  });

  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`Gemini API error: ${resp.status} ${text}`);
  }

  const data = await resp.json();
  const result = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!result) {
    throw new Error("Réponse vide de Gemini.");
  }
  return result.trim();
}

// ======================== ANALYZE CV ========================

async function analyzeCV(body: OptimizeRequest, apiKey: string): Promise<string> {
  const cvContent = body.cvText || formDataToString(body.formData);
  if (!cvContent) throw new Error("Aucun contenu de CV fourni.");

  const prompt = `Tu es un expert en recrutement et un coach professionnel français. Analyse le CV suivant et donne des conseils d'amélioration clairs et actionnables.

CV À ANALYSER:
"""
${cvContent}
"""

Donne ton analyse au format Markdown avec ces sections:

## Score global
Donne une note sur 100 avec une brève explication.

## Points forts
Liste 3-5 points forts du CV.

## Points à améliorer
Liste 3-5 faiblesses concrètes avec des suggestions précises pour les corriger.

## Suggestions de reformulation
Pour chaque expérience ou section importante, propose une version améliorée avec des verbes d'action et des résultats quantifiés.

## Compétences manquantes
Identifie les compétences que le candidat devrait mettre en avant ou acquérir selon son profil.

## Résumé professionnel suggéré
Propose un résumé professionnel de 3-4 lignes percutant.

Sois bienveillant mais direct. Utilise le français.`;

  return callGemini(prompt, apiKey);
}

// ======================== CREATE CV ========================

async function createCV(body: OptimizeRequest, apiKey: string): Promise<string> {
  if (!body.formData) throw new Error("Données du formulaire manquantes.");

  const formStr = formDataToString(body.formData);
  const targetRole = body.formData.targetRole || body.jobOffer?.title || "le poste souhaité";

  const prompt = `Tu es un expert en recrutement français. Crée un CV professionnel structuré et percutant à partir des informations suivantes.

POSTE VISE: ${targetRole}

INFORMATIONS DU CANDIDAT:
"""
${formStr}
"""

Crée un CV professionnel complet au format Markdown avec:

## [Nom du candidat]
[Email] | [Téléphone] | [Adresse]

### Profil professionnel
Un résumé de 3-4 lignes qui met en valeur les atouts du candidat pour le poste visé.

### Expériences professionnelles
Pour chaque expérience, reformule avec des verbes d'action et des résultats concrets quantifiés quand c'est possible.

### Formation
Mets en valeur les diplômes pertinents.

### Compétences
Organise les compétences par catégories (techniques, linguistiques, transversales).

### Centres d'intérêt (optionnel)
Ajoute une section si les informations permettent de la remplir.

Le CV doit être professionnel, concis et adapté au poste visé. Utilise le français. Ne invente pas d'informations, mais reformule et structure ce qui est fourni de manière professionnelle.`;

  return callGemini(prompt, apiKey);
}

// ======================== ADAPT CV ========================

async function adaptCV(body: OptimizeRequest, apiKey: string): Promise<string> {
  const cvContent = body.cvText || formDataToString(body.formData);
  if (!cvContent) throw new Error("Aucun CV fourni.");
  if (!body.jobOffer) throw new Error("Aucune offre d'emploi fournie.");

  const offer = body.jobOffer;

  const prompt = `Tu es un expert en recrutement français. Tu vas faire deux choses, dans l'ordre, pour aider ce candidat à postuler à cette offre précise.

OFFRE D'EMPLOI:
- Titre: ${offer.title}
- Entreprise: ${offer.company}
- Type de contrat: ${offer.contract_type || "non précisé"}
- Lieu: ${offer.location || "non précisé"}
- Compétences demandées: ${offer.competences?.join(", ") || "non précisées"}

DESCRIPTION DE L'OFFRE:
"""
${offer.description}
"""

CV ACTUEL DU CANDIDAT:
"""
${cvContent}
"""

Réponds au format Markdown en respectant EXACTEMENT cette structure, dans cet ordre:

## Ce qu'il te manque pour cette offre
Compare précisément le CV du candidat aux attentes de l'offre. Liste sous forme de puces :
- Les compétences ou mots-clés demandés par l'offre qui n'apparaissent pas (ou pas assez) dans le CV
- Les niveaux d'expérience, diplômes ou certifications demandés que le candidat ne semble pas avoir
- Pour chaque élément manquant, une suggestion concrète (le mentionner s'il le possède mais ne l'a pas écrit, une formation courte à suivre, ou comment compenser avec une expérience proche)
Si le profil correspond déjà très bien, dis-le clairement plutôt que d'inventer des manques.

## Ton score de correspondance
Donne un pourcentage de correspondance avec l'offre (0-100%) et une phrase d'explication.

## Ton CV adapté pour cette offre
Adapte maintenant le CV pour maximiser ses chances d'être sélectionné, au format:

### [Nom du candidat]
[Coordonnées]

#### Profil professionnel
Résume en 3-4 lignes pourquoi ce candidat est idéal pour CE poste précis. Utilise les mots-clés de l'offre.

#### Expériences professionnelles
Réorganise et reformule les expériences pour mettre en avant celles qui sont les plus pertinentes pour cette offre. Quantifie les résultats. Met en parallèle avec les besoins de l'offre.

#### Formation
Mets en avant les formations pertinentes pour ce poste.

#### Compétences clés pour ce poste
Liste d'abord les compétences qui correspondent à l'offre, puis les autres.

#### Atouts pour ce poste
Une section de 2-3 points qui montre l'alignement entre le profil et les besoins spécifiques de cette offre.

IMPORTANT:
- Ne mens jamais et n'invente pas d'expériences ou compétences que le candidat n'a pas
- Le "CV adapté" doit rester honnête: il reformule et met en avant l'existant, il n'ajoute jamais une compétence listée dans "Ce qu'il te manque"
- Utilise les mots-clés de l'offre dans le CV
- Sois stratégique: mets en avant les éléments qui correspondent le mieux aux besoins de l'entreprise
- Utilise le français`;

  return callGemini(prompt, apiKey);
}

// ======================== HELPERS ========================

function formDataToString(data?: CVFormData): string {
  if (!data) return "";

  let str = `Nom: ${data.fullName}\n`;
  if (data.email) str += `Email: ${data.email}\n`;
  if (data.phone) str += `Téléphone: ${data.phone}\n`;
  if (data.address) str += `Adresse: ${data.address}\n`;
  if (data.targetRole) str += `Poste visé: ${data.targetRole}\n`;
  if (data.summary) str += `\nRésumé: ${data.summary}\n`;

  if (data.experiences.length > 0) {
    str += "\nEXPÉRIENCES PROFESSIONNELLES:\n";
    data.experiences.forEach((exp, i) => {
      str += `${i + 1}. ${exp.position} chez ${exp.company} (${exp.startDate} - ${exp.endDate || "aujourd'hui"})\n`;
      if (exp.description) str += `   ${exp.description}\n`;
    });
  }

  if (data.educations.length > 0) {
    str += "\nFORMATION:\n";
    data.educations.forEach((edu, i) => {
      str += `${i + 1}. ${edu.diploma} - ${edu.school} (${edu.year || ""})\n`;
      if (edu.details) str += `   ${edu.details}\n`;
    });
  }

  if (data.skills.length > 0) {
    str += `\nCOMPÉTENCES: ${data.skills.join(", ")}\n`;
  }

  if (data.languages && data.languages.length > 0) {
    str += "\nLANGUES:\n";
    data.languages.forEach((lang) => {
      str += `- ${lang.name}: ${lang.level}\n`;
    });
  }

  return str;
}
