// Décroche — Custom branded auth emails via Resend
// Plugs into Supabase Auth's "Send Email" hook so every signup/reset/
// magic-link email is sent by Resend with Décroche's own design,
// instead of Supabase's default generic template.
//
// Setup (one-time, in the Supabase dashboard):
// 1. Deploy this function: supabase functions deploy send-auth-email
// 2. Set secrets:
//      supabase secrets set RESEND_API_KEY=re_xxx
//      supabase secrets set SEND_EMAIL_HOOK_SECRET=whsec_xxx (generate a random one)
// 3. Dashboard → Authentication → Hooks → "Send Email" → enable it,
//    point it at this function's URL, paste the same hook secret.

import { Webhook } from "npm:standardwebhooks@1.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, webhook-id, webhook-timestamp, webhook-signature",
};

interface HookPayload {
  user: {
    email: string;
    user_metadata?: { full_name?: string; name?: string };
  };
  email_data: {
    token: string;
    token_hash: string;
    redirect_to: string;
    email_action_type: "signup" | "recovery" | "invite" | "magiclink" | "email_change" | "reauthentication";
    site_url: string;
    token_new?: string;
    token_hash_new?: string;
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const payload = await req.text();
    const headers = Object.fromEntries(req.headers);
    const hookSecret = Deno.env.get("SEND_EMAIL_HOOK_SECRET");
    const resendApiKey = Deno.env.get("RESEND_API_KEY");

    if (!resendApiKey) {
      throw new Error("RESEND_API_KEY non configurée");
    }

    let data: HookPayload;

    if (hookSecret) {
      const wh = new Webhook(hookSecret);
      data = wh.verify(payload, headers) as HookPayload;
    } else {
      // Allows local testing without a hook secret configured yet
      data = JSON.parse(payload);
    }

    const { user, email_data } = data;
    const firstName =
      user.user_metadata?.full_name?.split(" ")[0] ||
      user.user_metadata?.name?.split(" ")[0] ||
      user.email.split("@")[0];

    const confirmUrl = buildConfirmUrl(email_data);
    const { subject, html } = renderEmail(email_data.email_action_type, firstName, confirmUrl);

    const resendResp = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: Deno.env.get("EMAIL_FROM") || "Décroche <onboarding@resend.dev>",
        to: [user.email],
        subject,
        html,
      }),
    });

    if (!resendResp.ok) {
      const text = await resendResp.text();
      throw new Error(`Resend error: ${resendResp.status} ${text}`);
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("send-auth-email error:", err);
    return new Response(
      JSON.stringify({
        error: {
          http_code: 500,
          message: err instanceof Error ? err.message : "Erreur inconnue",
        },
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

function buildConfirmUrl(email_data: HookPayload["email_data"]): string {
  const base = email_data.site_url || "";
  const params = new URLSearchParams({
    token_hash: email_data.token_hash,
    type: email_data.email_action_type,
    redirect_to: email_data.redirect_to || base,
  });
  return `${base}/auth/v1/verify?${params.toString()}`;
}

function renderEmail(
  type: HookPayload["email_data"]["email_action_type"],
  firstName: string,
  confirmUrl: string
): { subject: string; html: string } {
  switch (type) {
    case "signup":
      return {
        subject: "Confirme ton compte Décroche",
        html: wrapTemplate(
          "Bienvenue sur Décroche 👋",
          `Salut ${escapeHtml(firstName)},<br/><br/>
          Ton compte est presque prêt. Confirme ton adresse email pour commencer à décrocher ton prochain job.`,
          confirmUrl,
          "Confirmer mon compte"
        ),
      };
    case "recovery":
      return {
        subject: "Réinitialise ton mot de passe Décroche",
        html: wrapTemplate(
          "Réinitialisation du mot de passe",
          `Salut ${escapeHtml(firstName)},<br/><br/>
          Tu as demandé à réinitialiser ton mot de passe. Clique sur le bouton ci-dessous (valable 1 heure).
          Si tu n'es pas à l'origine de cette demande, ignore simplement cet email.`,
          confirmUrl,
          "Créer un nouveau mot de passe"
        ),
      };
    case "magiclink":
      return {
        subject: "Ton lien de connexion Décroche",
        html: wrapTemplate(
          "Connexion à Décroche",
          `Salut ${escapeHtml(firstName)},<br/><br/>
          Clique sur le bouton ci-dessous pour te connecter à ton espace Décroche.`,
          confirmUrl,
          "Me connecter"
        ),
      };
    case "email_change":
      return {
        subject: "Confirme ta nouvelle adresse email",
        html: wrapTemplate(
          "Changement d'adresse email",
          `Salut ${escapeHtml(firstName)},<br/><br/>
          Confirme ta nouvelle adresse email pour continuer à recevoir tes offres et candidatures.`,
          confirmUrl,
          "Confirmer ma nouvelle adresse"
        ),
      };
    default:
      return {
        subject: "Décroche — Vérification requise",
        html: wrapTemplate(
          "Vérification requise",
          `Salut ${escapeHtml(firstName)},<br/><br/>Clique sur le bouton ci-dessous pour continuer.`,
          confirmUrl,
          "Continuer"
        ),
      };
  }
}

function wrapTemplate(title: string, body: string, ctaUrl: string, ctaLabel: string): string {
  return `<!DOCTYPE html>
<html lang="fr">
  <body style="margin:0;padding:0;background-color:#F1F5F9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#F1F5F9;padding:32px 16px;">
      <tr>
        <td align="center">
          <table role="presentation" width="480" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;max-width:480px;width:100%;">
            <tr>
              <td style="background-color:#0A0E1A;padding:24px 32px;">
                <span style="color:#ffffff;font-size:20px;font-weight:700;">🧭 Décroche</span>
              </td>
            </tr>
            <tr>
              <td style="padding:32px;">
                <h1 style="margin:0 0 16px;color:#0A0E1A;font-size:20px;">${title}</h1>
                <p style="margin:0 0 24px;color:#475569;font-size:15px;line-height:1.6;">${body}</p>
                <table role="presentation" cellpadding="0" cellspacing="0">
                  <tr>
                    <td style="border-radius:10px;background-color:#10B981;">
                      <a href="${ctaUrl}" style="display:inline-block;padding:14px 28px;color:#ffffff;font-size:15px;font-weight:600;text-decoration:none;">${ctaLabel}</a>
                    </td>
                  </tr>
                </table>
                <p style="margin:24px 0 0;color:#94A3B8;font-size:13px;line-height:1.5;">
                  Si le bouton ne fonctionne pas, copie-colle ce lien dans ton navigateur :<br/>
                  <a href="${ctaUrl}" style="color:#10B981;word-break:break-all;">${ctaUrl}</a>
                </p>
              </td>
            </tr>
            <tr>
              <td style="padding:20px 32px;background-color:#F8FAFC;border-top:1px solid #E2E8F0;">
                <p style="margin:0;color:#94A3B8;font-size:12px;">© 2026 Décroche — Pas juste une candidature, un accompagnement jusqu'à la signature.</p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>`;
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
