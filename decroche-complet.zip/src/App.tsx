import { FormEvent, useEffect, useState } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  Bell,
  BriefcaseBusiness,
  Check,
  ChevronDown,
  CircleHelp,
  Compass,
  Clock3,
  Globe2,
  HeartHandshake,
  Mail,
  Menu,
  Mic2,
  MousePointer2,
  Network,
  ShieldCheck,
  Sparkles,
  Target,
  TrendingUp,
  X,
} from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { AuthModal, type AuthModalMode } from '@/components/AuthModal';
import { AccountButton } from '@/components/AccountButton';
import { Dashboard } from '@/components/Dashboard';

const navItems = [
  { label: 'Comment ça marche', href: '#methode' },
  { label: 'Le marché caché', href: '#marche-cache' },
  { label: 'Tarifs', href: '#tarifs' },
];

const features = [
  {
    number: '01',
    icon: Network,
    title: 'Toutes les offres. Même celles qu’on ne voit pas.',
    text: 'France Travail, La Bonne Alternance et notre réseau d’entreprises qui recrutent sans publier d’annonce. Un seul endroit, zéro recherche éparpillée.',
    tags: ['France Travail', 'La Bonne Alternance', 'Marché caché'],
    accent: 'blue',
  },
  {
    number: '02',
    icon: Target,
    title: 'Tu swipes. L’IA fait le tri.',
    text: 'Chaque offre reçoit un score de match selon ton profil, tes envies et ce que tu veux devenir. Tu sais où mettre ton énergie.',
    tags: ['Score de match', 'Feed personnalisé', 'Swipe rapide'],
    accent: 'green',
  },
  {
    number: '03',
    icon: Sparkles,
    title: 'Une candidature qui te ressemble.',
    text: 'Ton CV et ta lettre s’adaptent à chaque offre. Pas de texte générique : ton expérience, tes mots, le bon angle pour le bon recruteur.',
    tags: ['CV adapté', 'Lettre IA', 'Conseils personnalisés'],
    accent: 'orange',
  },
];

const afterSteps = [
  { icon: Mail, title: 'On suit les réponses', text: 'Ta boîte mail est connectée en lecture seule. On repère les entretiens, les refus et les relances à faire.' },
  { icon: Mic2, title: 'On prépare l’entretien', text: 'Simulation avec l’IA, questions probables selon l’offre et feedback concret pour arriver confiant.' },
  { icon: TrendingUp, title: 'On rebondit ensemble', text: 'Un refus devient un plan : compétences à renforcer, prochaines offres et nouvel angle d’approche.' },
];

function App() {
  const { user, loading, signOut } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [authMode, setAuthMode] = useState<AuthModalMode | null>(null);

  function openAuth(mode: AuthModalMode) {
    setAuthMode(mode);
  }

  function closeAuth() {
    setAuthMode(null);
  }

  function closeMenu() {
    setIsMenuOpen(false);
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!email.trim()) return;
    setSubmitted(true);
  }

  useEffect(() => {
    if (submitted && user) {
      closeAuth();
      setSubmitted(false);
    }
  }, [user, submitted]);

  if (!loading && user) {
    return <Dashboard onSignOut={async () => { await signOut(); }} />;
  }

  return (
    <div className="site-shell">
      {authMode && (
        <AuthModal mode={authMode} onClose={closeAuth} onSwitchMode={setAuthMode} />
      )}

      <header className="site-header">
        <a className="brand" href="#top" aria-label="Décroche, accueil">
          <span className="brand-mark"><Compass size={20} strokeWidth={2.5} /></span>
          <span>Décroche</span>
        </a>
        <nav className={`main-nav ${isMenuOpen ? 'is-open' : ''}`}>
          {navItems.map((item) => (
            <a key={item.href} href={item.href} onClick={closeMenu}>{item.label}</a>
          ))}
          {loading ? null : user ? (
            <button className="nav-login" type="button" onClick={() => openAuth('signin')}>Mon espace</button>
          ) : (
            <button className="nav-login" type="button" onClick={() => openAuth('signin')}>Se connecter <ArrowRight size={16} /></button>
          )}
        </nav>
        {loading ? null : user ? <AccountButton onOpenAuth={openAuth} /> : (
          <button className="header-cta" type="button" onClick={() => openAuth('signup')}>
            Commencer gratuitement <ArrowRight size={16} />
          </button>
        )}
        <button className="menu-toggle" type="button" aria-label={isMenuOpen ? 'Fermer le menu' : 'Ouvrir le menu'} onClick={() => setIsMenuOpen((open) => !open)}>
          {isMenuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </header>

      <main id="top">
        <section className="hero section-pad">
          <div className="hero-copy">
            <div className="hero-pill"><span className="eyebrow-dot" /> On t’accompagne jusqu’à la signature, pas juste la candidature</div>
            <h1>Décroche ton prochain job <span className="hero-highlight">plus vite</span></h1>
            <p className="hero-text">Toutes les offres au même endroit, un CV qui s’adapte à chaque opportunité et un coach qui te suit après l’envoi. Tu candidates, on t’accompagne jusqu’à l’entretien.</p>
            {!loading && !user ? (
              <form className="signup-form" id="inscription" onSubmit={handleSubmit}>
                <label className="sr-only" htmlFor="email">Ton adresse email</label>
                <input id="email" type="email" placeholder="ton.email@exemple.fr" value={email} onChange={(event) => setEmail(event.target.value)} required />
                <button className="button button-primary" type="submit">{submitted ? 'C’est parti' : 'Commencer gratuitement'} <ArrowRight size={19} /></button>
              </form>
            ) : !loading && user ? (
              <div className="hero-cta-connected" id="inscription">
                <button className="button button-primary" type="button" onClick={() => openAuth('signin')}>
                  Accéder à mon espace <ArrowRight size={19} />
                </button>
                <p className="connected-hint"><BadgeCheck size={16} /> Tu es connecté avec {user.email}</p>
              </div>
            ) : null}
            {!loading && !user && (
              <p className="form-note">Sans carte bancaire · Gratuit pour commencer · Prêt en 2 minutes</p>
            )}
            {submitted && !loading && !user && <p className="success-note"><BadgeCheck size={16} /> Prépare ton compte : un email, un mot de passe, et c’est parti.</p>}
          </div>
          <div className="hero-product" aria-label="Aperçu de l’application Décroche">
            <div className="product-glow" />
            <div className="dashboard-card">
              <div className="dash-topbar"><div className="mini-brand"><span className="mini-mark"><Compass size={12} /></span> Décroche</div><div className="dash-actions"><Bell size={16} /><span className="profile-dot">NA</span></div></div>
              <div className="dash-body">
                <div className="dash-welcome"><div><span className="dash-kicker">MARDI 25 AOÛT</span><h3>Bonjour Nour <span>✦</span></h3><p>On avance sur ta prochaine opportunité ?</p></div><div className="progress-ring"><span>72%</span></div></div>
                <div className="dash-section-title"><span>Ton prochain match</span><a href="#fonctionnalites">Voir tout <ArrowRight size={13} /></a></div>
                <div className="job-card">
                  <div className="job-header"><div className="company-logo">L</div><div><strong>Chargé·e de communication</strong><span>La Ruche · Paris / Hybride</span></div><span className="match-score">92%</span></div>
                  <div className="job-tags"><span><BriefcaseBusiness size={12} /> Alternance</span><span><Clock3 size={12} /> Publiée il y a 2j</span></div>
                  <div className="match-bar"><span style={{ width: '92%' }} /></div>
                  <div className="job-footer"><span><Sparkles size={14} /> Ton CV est prêt</span><button type="button" aria-label="Voir l’offre"><ArrowUpRight size={16} /></button></div>
                </div>
                <div className="dash-section-title second-title"><span>Ta suite, déjà préparée</span><span className="tiny-label">CETTE SEMAINE</span></div>
                <div className="next-actions"><div><span className="action-icon action-green"><Mic2 size={16} /></span><p><strong>Simulation entretien</strong><small>15 min · selon ton offre</small></p><ChevronDown size={15} /></div><div><span className="action-icon action-blue"><Mail size={16} /></span><p><strong>1 réponse détectée</strong><small>À lire dans ton suivi</small></p><ArrowRight size={15} /></div></div>
              </div>
            </div>
            <div className="floating-card floating-match"><span className="floating-icon"><Target size={16} /></span><div><strong>Très bon match</strong><small>Ton profil se démarque ici</small></div><span className="floating-check"><Check size={14} /></span></div>
            <div className="floating-card floating-ai"><Sparkles size={15} /><span>IA en action</span></div>
          </div>
        </section>

        <section className="trust-strip"><div className="trust-label">SOURCES & ENGAGEMENTS</div><div className="trust-logos"><span><Globe2 size={17} /> France Travail</span><span><Network size={17} /> La Bonne Alternance</span><span><ShieldCheck size={17} /> RGPD</span><span><HeartHandshake size={17} /> Sans filtre discriminant</span></div></section>

        <section className="problem-section section-pad" id="methode">
          <div className="section-intro centered"><div className="eyebrow"><span className="eyebrow-dot" /> Le vrai problème</div><h2>Envoyer une candidature,<br /><span>ce n’est pas trouver un emploi.</span></h2><p>Les outils te déposent devant la porte. Nous, on reste avec toi jusqu’à ce qu’elle s’ouvre.</p></div>
          <div className="comparison-grid"><div className="comparison-card old-way"><div className="comparison-label">L’ANCIENNE FAÇON <span>Ça s’arrête là</span></div><div className="comparison-stat"><strong>20 min</strong><span>/ candidature</span></div><ul><li><MousePointer2 size={15} /> Copier-coller le même CV partout</li><li><MousePointer2 size={15} /> Rédiger une lettre générique</li><li><MousePointer2 size={15} /> Remplir des formulaires sans fin</li><li><MousePointer2 size={15} /> Attendre. Sans savoir pourquoi.</li></ul><div className="card-bottom-muted"><span className="muted-line" /><span>Silence radio</span><span className="muted-line" /></div></div><div className="comparison-card new-way"><div className="comparison-label">AVEC DÉCROCHE <span><Sparkles size={14} /> On continue avec toi</span></div><div className="comparison-stat"><strong>2 min</strong><span>/ candidature</span></div><ul><li><Check size={17} /> Un CV et une lettre adaptés par l’IA</li><li><Check size={17} /> Le bon décideur, au bon moment</li><li><Check size={17} /> Tes réponses suivies automatiquement</li><li><Check size={17} /> Un coach jusqu’à l’entretien</li></ul><div className="card-bottom-result"><TrendingUp size={17} /><span>Jusqu’à la signature</span><ArrowRight size={17} /></div></div></div>
        </section>

        <section className="hidden-market section-pad" id="marche-cache"><div className="section-intro"><div className="eyebrow"><span className="eyebrow-dot" /> Ce que les autres ne te montrent pas</div><h2>Le meilleur poste n’a<br /><span>peut-être pas d’annonce.</span></h2><p>Une grande partie des recrutements se fait en dehors des plateformes. On te donne accès aux entreprises qui recrutent en silence — et à la personne à contacter.</p><a className="text-link" href="#fonctionnalites">Découvrir le marché caché <ArrowRight size={17} /></a></div><div className="network-visual"><div className="network-orbit orbit-one" /><div className="network-orbit orbit-two" /><div className="network-center"><Sparkles size={29} /><span>Marché<br />caché</span></div><div className="network-node node-one"><div className="node-avatar node-coral">A</div><span>Atelier 19</span></div><div className="network-node node-two"><div className="node-avatar node-blue">L</div><span>La Ruche</span></div><div className="network-node node-three"><div className="node-avatar node-green">O</div><span>Octo Tech</span></div><div className="network-node node-four"><div className="node-avatar node-dark">M</div><span>Maison M.</span></div><div className="network-caption"><span className="pulse-dot" /> Des entreprises recrutent sans annonce</div></div></section>

        <section className="features-section section-pad" id="fonctionnalites"><div className="section-intro centered"><div className="eyebrow"><span className="eyebrow-dot" /> Ton avantage, à chaque étape</div><h2>Tout ce qu’il faut pour<br /><span>passer devant les autres.</span></h2><p>Pas plus d’outils. Un meilleur accompagnement, du premier swipe au dernier “oui”.</p></div><div className="feature-list">{features.map((feature) => { const Icon = feature.icon; return <article className={`feature-row accent-${feature.accent}`} key={feature.number}><div className="feature-number">{feature.number}</div><div className="feature-icon"><Icon size={25} /></div><div className="feature-content"><h3>{feature.title}</h3><p>{feature.text}</p><div className="feature-tags">{feature.tags.map((tag) => <span key={tag}>{tag}</span>)}</div></div><ArrowUpRight className="feature-arrow" size={21} /></article>; })}</div></section>

        <section className="after-application section-pad"><div className="after-heading"><div className="eyebrow eyebrow-light"><span className="eyebrow-dot" /> Le moment qui change tout</div><h2>Et après avoir cliqué<br /><span>sur “Envoyer” ?</span></h2><p>Tu ne repars pas seul. C’est précisément là que Décroche commence à faire la différence.</p></div><div className="after-grid">{afterSteps.map((step, index) => { const Icon = step.icon; return <div className="after-step" key={step.title}><span className="step-index">0{index + 1}</span><div className="after-icon"><Icon size={22} /></div><h3>{step.title}</h3><p>{step.text}</p></div>; })}</div><div className="quote-banner"><HeartHandshake size={21} /><p><strong>Un refus ne dit pas qui tu es.</strong> Il dit seulement quoi ajuster pour la suite.</p><ArrowRight size={18} /></div></section>

        <section className="pricing-section section-pad" id="tarifs"><div className="section-intro centered"><div className="eyebrow"><span className="eyebrow-dot" /> Simple et transparent</div><h2>Commence maintenant.<br /><span>Paie quand ça marche.</span></h2><p>Explore gratuitement. Passe à la vitesse supérieure quand tu es prêt.</p></div><div className="pricing-grid"><div className="price-card"><div className="price-title"><span>Découverte</span><span className="price-badge">Pour commencer</span></div><p className="price-subtitle">Pour reprendre confiance</p><div className="price"><strong>0 €</strong><span>pour toujours</span></div><ul><li><Check size={17} /> Recherche France Travail + LBA</li><li><Check size={17} /> Accès au marché caché</li><li><Check size={17} /> 10 swipes par jour</li><li><Check size={17} /> 2 CV et lettres adaptés / mois</li><li><Check size={17} /> Suivi de tes candidatures</li></ul>{!loading && user ? <button className="button button-outline" type="button" onClick={() => openAuth('signin')}>Accéder à mon espace <ArrowRight size={17} /></button> : <button className="button button-outline" type="button" onClick={() => openAuth('signup')}>Créer mon compte gratuit <ArrowRight size={17} /></button>}</div><div className="price-card price-card-pro"><div className="recommended">RECOMMANDÉ</div><div className="price-title"><span>Pro</span><span className="crown">✦</span></div><p className="price-subtitle">Pour décrocher plus vite</p><div className="price"><strong>9,99 €</strong><span>/ mois</span></div><ul><li><Check size={17} /> Tout Découverte, plus :</li><li><Check size={17} /> Swipes et candidatures illimités</li><li><Check size={17} /> CV et lettres IA illimités</li><li><Check size={17} /> Fiche décideur + angle d’accroche</li><li><Check size={17} /> Coach entretien IA personnalisé</li><li><Check size={17} /> Plan de compétences sur mesure</li></ul>{!loading && user ? <button className="button button-dark" type="button" onClick={() => openAuth('signin')}>Accéder à mon espace <ArrowRight size={17} /></button> : <button className="button button-dark" type="button" onClick={() => openAuth('signup')}>Commencer avec Pro <ArrowRight size={17} /></button>}<p className="price-footnote">Sans engagement · Résiliable à tout moment</p></div></div></section>

        <section className="inclusion-section section-pad" id="inclusion"><div className="section-intro centered"><div className="eyebrow"><span className="eyebrow-dot" /> Nos engagements</div><h2>Pour tout le monde.<br /><span>Sans exception.</span></h2><p>On ne filtre personne. On s’adapte à ta situation, pas l’inverse.</p></div><div className="inclusion-grid"><div className="inclusion-card"><span className="inclusion-icon"><HeartHandshake size={24} /></span><h3>Femmes voilées bienvenues</h3><p>Pas de mise à l’écart, pas de filtrage. Tu accèdes aux mêmes offres, aux mêmes outils et aux mêmes chances — un point, c’est tout.</p></div><div className="inclusion-card"><span className="inclusion-icon"><BadgeCheck size={24} /></span><h3>Diplôme ou pas diplôme</h3><p>Bac+5, bac+3, sans diplôme : on s’adapte à ton parcours. Ce qui compte, c’est ce que tu peux apporter, pas ce qui manque sur ton CV.</p></div><div className="inclusion-card"><span className="inclusion-icon"><ShieldCheck size={24} /></span><h3>Tes données, protégées</h3><p>Connexion mail en lecture seule, chiffrement et conformité RGPD. Rien n’est partagé sans ton accord explicite.</p></div><div className="inclusion-card"><span className="inclusion-icon"><Sparkles size={24} /></span><h3>L’IA prépare, tu envoies</h3><p>Rien n’est envoyé à ton insu. On prépare le CV, la lettre et l’angle — tu gardes le contrôle sur chaque candidature.</p></div></div></section>

        <section className="final-cta section-pad"><div className="final-cta-content"><div className="final-mark"><Compass size={31} /></div><div className="eyebrow eyebrow-light"><span className="eyebrow-dot" /> La suite t’attend</div><h2>Tu n’as pas besoin<br />de plus de courage.<br /><span>Tu as besoin d’un plan.</span></h2><p>Décroche t’accompagne jusqu’à ce que ton prochain “oui” arrive.</p>{!loading && user ? <button className="button button-light" type="button" onClick={() => openAuth('signin')}>Accéder à mon espace <ArrowRight size={18} /></button> : <button className="button button-light" type="button" onClick={() => openAuth('signup')}>Commencer gratuitement <ArrowRight size={18} /></button>}<span className="final-note">Gratuit · Sans carte bancaire · À ton rythme</span></div></section>
      </main>

      <footer className="site-footer"><div className="footer-brand"><a className="brand" href="#top"><span className="brand-mark"><Compass size={20} strokeWidth={2.5} /></span><span>Décroche</span></a><p>Pas juste une candidature.<br />Un accompagnement jusqu’à la signature.</p></div><div className="footer-links"><div><strong>Produit</strong><a href="#methode">Comment ça marche</a><a href="#marche-cache">Marché caché</a><a href="#tarifs">Tarifs</a></div><div><strong>À propos</strong><a href="#top">Notre mission</a><a href="#top">Pour les entreprises</a><a href="#top">Nous contacter</a></div><div><strong>Confiance</strong><a href="#top">Données & RGPD</a><a href="#top">Aide</a><a href="#top">Mentions légales</a></div></div><div className="footer-bottom"><span>© 2026 Décroche</span><span>Fait pour celles et ceux qui avancent.</span><span className="made-with"><CircleHelp size={15} /> Une question ?</span></div></footer>
    </div>
  );
}

export default App;
