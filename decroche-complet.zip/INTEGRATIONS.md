# Intégrations Décroche

État des lieux après amélioration : **France Travail**, **Gemini** et la
**base de données** (Supabase Postgres) étaient déjà branchés dans le
projet — voir `src/lib/api.ts` et `supabase/functions/`. Ce qui a été
ajouté : **Resend**, pour que les emails d'authentification (confirmation
de compte, mot de passe oublié, changement d'email) soient envoyés par
Resend avec le design "Décroche", au lieu des emails génériques Supabase.

## Variables déjà utilisées côté frontend (`.env`)
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

## Secrets à définir côté serveur (Edge Functions Supabase)
Ces clés ne vont jamais dans `.env` du frontend — elles se configurent avec
la CLI Supabase ou dans Dashboard → Project Settings → Edge Functions → Secrets.

Commandes prêtes avec les clés fournies (France Travail, Resend) :

```
supabase secrets set FRANCE_TRAVAIL_CLIENT_ID=PAR_decroche_f4973d406b6bf26a8ebf1427406557b6db4b45282cea0905b774f4e8791ac950
supabase secrets set FRANCE_TRAVAIL_SECRET=e4e58aa2dae70424100be5be72e04a6483cef0464bdc7578e6281b1f020a0037
supabase secrets set RESEND_API_KEY=re_KVUXJxFd_8jn7KGN492f1NqZdJPAUGmKd
supabase secrets set GEMINI_API_KEY=<ta clé Gemini, voir note ci-dessous>
supabase secrets set SEND_EMAIL_HOOK_SECRET=whsec_xxx   # génère une valeur aléatoire
supabase secrets set EMAIL_FROM="Décroche <contact@ton-domaine.com>"
```

⚠️ **La clé Gemini que tu as collée (`AQ.Ab8RN6Lp...`) n'a pas le bon
format.** Une clé API Gemini/Google AI Studio commence toujours par
`AIzaSy...`. Ce que tu as collé ressemble à un jeton OAuth ou un ID de
session, pas à une clé API. Récupère la bonne sur
**aistudio.google.com/apikey** (bouton "Create API key", gratuit, aucune
carte requise) puis remplace-la dans la commande ci-dessus.

⚠️ **Les clés "Neon" que tu as données sont en fait des clés Clerk**
(`pk_test_...clerk.accounts.dev` et `sk_test_...`) — Clerk et Neon sont deux
services différents (auth vs base de données). Ce projet-ci utilise encore
**Supabase** pour l'auth et la base de données (déjà configuré, déjà
fonctionnel avec ton `DATABASE_URL` Neon en réserve si tu veux migrer plus
tard). Si tu veux migrer cette appli vers Clerk + Neon comme évoqué avec
Devin, dis-le moi clairement — c'est un chantier séparé, plus gros, que je
peux faire mais qui remplace l'authentification actuelle.

### Modèle Gemini utilisé
La fonction utilise déjà **`gemini-3.6-flash`** : gratuit avec un bon quota
(rate limits généreux) et rapide, le bon compromis pour du texte (analyse
de CV, offres) sans coût. Pas besoin de changer.

`SUPABASE_URL` et `SUPABASE_SERVICE_ROLE_KEY` sont déjà fournis
automatiquement à toutes les Edge Functions par Supabase.

## Nouvelle fonction : `send-auth-email`
Fichier : `supabase/functions/send-auth-email/index.ts`

Elle reçoit le webhook "Send Email" de Supabase Auth à chaque inscription,
demande de reset de mot de passe, magic link ou changement d'email, puis
envoie elle-même l'email via Resend avec un template HTML aux couleurs de
Décroche (vert émeraude `#10B981`, fond `#0A0E1A`).

### Étapes pour l'activer (une seule fois)
1. Déployer la fonction :
   ```
   supabase functions deploy send-auth-email
   ```
2. Définir les secrets `RESEND_API_KEY` et `SEND_EMAIL_HOOK_SECRET` (voir
   au-dessus).
3. Dans le Dashboard Supabase → **Authentication → Hooks** → active
   **"Send Email"**, colle l'URL de la fonction déployée
   (`https://<ton-projet>.supabase.co/functions/v1/send-auth-email`) et le
   même `SEND_EMAIL_HOOK_SECRET`.
4. (Recommandé) Dans Resend, ajoute et vérifie ton propre nom de domaine
   pour pouvoir envoyer depuis `contact@ton-domaine.com` plutôt que
   `onboarding@resend.dev` — meilleure délivrabilité, moins de risque de
   spam.

Sans cette activation dans le dashboard, Supabase continue d'envoyer ses
emails par défaut (le code ne casse rien tant que le hook n'est pas
branché).

## Nouveau : "Postuler avec mon CV" sous chaque offre
Chaque carte d'offre (`JobBoard.tsx`) a maintenant un bouton **"Postuler
avec mon CV"**. Au clic :
1. Récupère le dernier CV enregistré par l'utilisateur (table `user_cvs`,
   via `getUserCVs()`).
2. Envoie ce CV + le détail de l'offre à Gemini (`adapt_cv`), qui répond
   en 3 parties, dans l'ordre :
   - **Ce qu'il te manque** — compétences, expérience ou diplômes demandés
     par l'offre absents du CV, avec une suggestion pour chacun
   - **Score de correspondance** — pourcentage + explication
   - **CV adapté** — le CV reformulé et réordonné pour cette offre précise
     (sans jamais inventer une compétence que le candidat n'a pas)

Si l'utilisateur n'a pas encore de CV enregistré, un message l'invite à en
créer un dans l'onglet "Mon CV" (lien direct depuis la modale).
